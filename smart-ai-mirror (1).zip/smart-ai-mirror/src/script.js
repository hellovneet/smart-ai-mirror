// Product Line Database (MAISON VINEET x LUXE)
const PRODUCT_CATALOG = {
  "RFID_TAG_001": {
    brand: "Maison Vineet",
    name: "Emerald Silk Blazer",
    color: "Cool / Winter Deep Green",
    sizes: ["S", "M", "L"],
    stockStatus: "In Stock (3 Left)"
  },
  "RFID_TAG_002": {
    brand: "Luxe",
    name: "Terracotta Oversized Hoodie",
    color: "Warm / Autumn Earthy Orange",
    sizes: ["M", "XL"],
    stockStatus: "Low Stock (1 Left)"
  },
  "RFID_TAG_003": {
    brand: "Maison Vineet",
    name: "Charcoal Tailored Vest",
    color: "Neutral / Minimalist Slate",
    sizes: ["S", "L", "XL"],
    stockStatus: "In Stock (5 Left)"
  }
};

const UNDERTONES = [
  { type: "Warm (Amber / Earthy)", palette: "Earth Tones (Warm Amber, Olive, Terracotta)", rec: "Maison Vineet Sahara Beige Trench", class: "warm" },
  { type: "Cool (Jewel Tones)", palette: "Jewel Tones (Emerald, Sapphire, Deep Plum)", rec: "Maison Vineet Emerald Silk Blazer", class: "cool" },
  { type: "Neutral (Balanced)", palette: "Universal Tones (Teal, Dust Rose, Charcoal)", rec: "Luxe Minimalist Dust Rose Tee", class: "neutral" }
];

// Initialize Camera with Fallback background if blocked
async function initWebcam() {
  const video = document.getElementById('webcam');
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 1280 }, height: { ideal: 720 } },
      audio: false
    });
    video.srcObject = stream;
  } catch (err) {
    console.warn("Webcam access restricted or unavailable. Running in Fallback Preview Mode.", err);
    document.querySelector('.kiosk-container').style.background = 
      'radial-gradient(circle at 50% 50%, #1e1b4b 0%, #09090b 100%)';
    video.style.display = 'none';
  }
}

let tagKeys = Object.keys(PRODUCT_CATALOG);
let currentTagIdx = 0;
let undertoneIdx = 0;

function cycleKioskState() {
  currentTagIdx = (currentTagIdx + 1) % tagKeys.length;
  let activeTag = tagKeys[currentTagIdx];
  let item = PRODUCT_CATALOG[activeTag];

  undertoneIdx = (undertoneIdx + 1) % UNDERTONES.length;
  let u = UNDERTONES[undertoneIdx];

  document.getElementById('undertone-status').innerText = u.type;
  document.getElementById('undertone-status').className = `value ${u.class}`;
  document.getElementById('palette-text').innerText = `Palette: ${u.palette}`;
  document.getElementById('ai-rec').innerText = `AI Pick: ${u.rec}`;

  document.getElementById('rfid-tag-label').innerText = `HELD ITEM (RFID: ${activeTag}):`;
  document.getElementById('item-brand').innerText = `Brand: ${item.brand} | ${item.name}`;
  document.getElementById('item-color').innerText = `Color Profile: ${item.color}`;
  document.getElementById('item-sizes').innerText = `Sizes Available: ${item.sizes.join(', ')}`;
  document.getElementById('item-stock').innerText = `Inventory: ${item.stockStatus}`;
}

window.addEventListener('DOMContentLoaded', () => {
  initWebcam();
  setInterval(cycleKioskState, 5000);
});